# prender el log
swirl_options(swirl_logging = TRUE)
